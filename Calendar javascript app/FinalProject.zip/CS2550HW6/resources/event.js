var text = '{ "eventList" : [' +
'{ "eventName":"Independence Day" , "eventMonth":"July","eventDay": "4", "startTime":"12am", "endTime":"11:59pm" }, ' +
'{ "eventName":"Classes End" , "eventMonth":"May","eventDay": "12", "startTime":"12am", "endTime":"7pm" }, ' +
'{ "eventName":"Christmas" , "eventMonth":"December","eventDay": "25", "startTime":"12am", "endTime":"11:59pm" } ]}';